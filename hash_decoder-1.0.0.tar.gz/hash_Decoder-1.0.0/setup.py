from setuptools import setup, find_packages

setup(
    name='hash_Decoder',  # Name of your package
    version='1.0.0',  # Version of your package
    author='Shah Kaif',
    author_email='kaifs00911@gmail.com',
    description='A command-line tool for decoding various hash types using wordlists.',  # Short description
    long_description=open('README.md').read(),  # Long description from README file
    long_description_content_type='text/markdown',  # Format of the long description
    url='https://github.com/SKaif009/hashDecoder',
    packages=find_packages(),  # Automatically find packages in the directory
    classifiers=[  # Classifiers help users find your package
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',  # Specify the Python version required
    install_requires=[  # List of dependencies
        'passlib',  # Required for NTLM hash handling
        'colorama',  # Required for colored output
        'rich',  # Required for rich console output
        'psutil',  # Required for system resource usage
    ],
    entry_points={  # Define entry points for command-line scripts
        'console_scripts': [
            'hash_Decoder=hash_Decoder:main',  # Command line command
        ],
    },

)