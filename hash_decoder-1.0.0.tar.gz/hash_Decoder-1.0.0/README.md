Hash Decoder
============

Overview
=========
This Python script is designed to decode various hash types using a wordlist. It is particularly useful for recovering passwords or other sensitive information that has been hashed.

Features
=========
Supports multiple hash algorithms (e.g., MD5, SHA-1, SHA-256, etc).
Utilizes a wordlist for brute-force attacks.
Provides clear output indicating success or failure of the decoding process.

Requirements
============
Python 3.x
hashlib library (included in Python standard library)
A wordlist file containing potential passwords

Installation
============
Clone the repository or download the script.
Ensure you have Python 3.x installed on your machine.
Place your wordlist file in the same directory as the script.

Step 1. : Create venv python -m venv venv 
<br/>step 2. : Run source venv/bin/activate 
<br/>step 3. : Extract hash_Decoder tool in venv [gunzip hash_decoder1.0.0.tar.zp | tar -xvf hash_decoder1.0.0.tar]
<br/>step 4. : cd hash_Decoder1.0.0  [Goto hash_Decoder1.0.0 folder]
<br/>step 5. : pip install . -v  [this will install all the packages for hash decoder scipts]<br/>
step 6. : pip install setuptools
step 7. : Now you can run these script   [python3 hashDecoder.py]<br/>


Usage
=====
To run the script, use the following command in your terminal.

Open Terminal
==============
python hashDecoder.py <hash_type> <hash_value> <wordlist_file>

Parameters
==========
<hash_type>: The type of hash you are trying to decode (e.g., md5, sha1, sha256, etc).
<hash_value>: The hash value you want to decode.
<wordlist_file>: The path to your wordlist file.

Example
=======
python hashDecoder.py --md5 5d41402abc4b2a76b9719d911017c592 -w wordlist.txt

Output
=======
The script will output the decoded password if found, or a message indicating that the password was not found in the wordlist.

Testing File
=============
The hashes.txt is provided for testing purpose you can run (-f) to read hashes in hashes.txt.

Wordlists
=========
By default Rockyou.txt is available for these project make sure use (-w) to locate your wordlist.
