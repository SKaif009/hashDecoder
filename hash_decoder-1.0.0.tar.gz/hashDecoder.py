import hashlib
import struct
from passlib.hash import nthash
from colorama import Fore, Style
import random
import platform
from rich.console import Console
import psutil
import time
import io
import os
import re
import sys
import argparse
from collections import namedtuple
# ====================================================================================================================
out_dict = {}

class Hashid:
    """
    To identify The Hash id These Class is to be used.
    """
    @staticmethod
    def identify_hashes(strings):
        """
        Identify various hashes from a list of strings.
        """
        ntlm_pattern = re.compile(r'^[^:]+:NTLM:([0-9a-fA-F]{32})$',re.IGNORECASE)
        md5_pattern = re.compile(r'^[0-9a-fA-F]{32}$',re.IGNORECASE)
        sha1_pattern = re.compile(r'^[a-f0-9]{40}$',re.IGNORECASE)
        sha256_pattern = re.compile(r'^[A-Fa-f0-9]{64}$',re.IGNORECASE)
        sha512_pattern = re.compile(r'^[A-Fa-f0-9]{128}$',re.IGNORECASE)
        md5crypt_pattern = re.compile(r'\$(1)\$[A-Za-z0-9./]{1,}\$[A-Za-z0-9./]{1,}',re.IGNORECASE)
        sha256crypt_pattern = re.compile(r'\$(5)\$[A-Za-z0-9./]{1,}\$[A-Za-z0-9./]{1,}',re.IGNORECASE)
        sha512crypt_pattern = re.compile(r'\$(6)\$[A-Za-z0-9./]{1,}\$[A-Za-z0-9./]{1,}',re.IGNORECASE)

        ntlm_hashes = []
        md5_hashes = []
        sha1_hashes = []
        sha256_hashes = []
        sha512_hashes = []
        md5crypt_hashes = []
        sha256crypt_hashes = []
        sha512crypt_hashes = []
        not_hash = []

        try:
            for s in strings:
                if ntlm_pattern.match(s):
                    ntlm_hashes.append(s)
                elif md5_pattern.match(s):
                    md5_hashes.append(s)
                elif sha1_pattern.match(s):
                    sha1_hashes.append(s)
                elif sha256_pattern.match(s):
                    sha256_hashes.append(s)
                elif sha512_pattern.match(s):
                    sha512_hashes.append(s)
                elif md5crypt_pattern.match(s):
                    md5crypt_hashes.append(s)
                elif sha256crypt_pattern.match(s):
                    sha256crypt_hashes.append(s)
                elif sha512crypt_pattern.match(s):
                    sha512crypt_hashes.append(s)
                else:
                    not_hash.append(s)  # Append non-hash strings to not_hash
        except Exception as e:
            print(f"Error processing '{s}': {e}")

        return (ntlm_hashes, md5_hashes, sha1_hashes, sha256_hashes, sha512_hashes,
                md5crypt_hashes, sha256crypt_hashes, sha512crypt_hashes, not_hash)



# ====================================================================================================================

class MD4_Generate:
    width = 32
    mask = 0xFFFFFFFF

    h = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476]

    def __init__(self, msg=None):
        """
        :param msg: arbitrary message which user want to do encrypt [For Ex: hello] hello is a msg
        """
        if msg is None:
            msg = b""

        self.msg = msg

        ml = len(msg) * 8
        msg += b"\x80"
        msg += b"\x00" * (-(len(msg) + 8) % 64)  # Ans = 56
        msg += struct.pack("<Q", ml)  # Ans = 64
        # print(len(msg))

        self._process([msg[i:i + 64] for i in range(0, len(msg), 64)])

    def __eq__(self, other):
        return self.h == other.h

    def bytes(self):
        return struct.pack("<4L", *self.h)

    def hexbytes(self):
        return self.hexdigest().encode()

    def hexdigest(self):
        return "".join(f"{value:02x}" for value in self.bytes())

    def _process(self, chunks):
        for chunk in chunks:
            X, h = list(struct.unpack("<16I", chunk)), self.h.copy()
            # print(X)

            # Round 1
            Xi = [3, 7, 11, 19]
            for n in range(16):
                i, j, k, l = map(lambda x: x % 4, range(-n, -n + 4))
                K, S = n, Xi[n % 4]
                hn = h[i] + MD4_Generate.F(h[j], h[k], h[l]) + X[K]
                # print("hn",hn)
                h[i] = MD4_Generate.lrot(hn & MD4_Generate.mask, S)
                # print("h[i]",h[i])

            # Round 2
            Xi = [3, 5, 9, 13]
            for n in range(16):
                i, j, k, l = map(lambda x: x % 4, range(-n, -n + 4))
                K, S = n % 4 * 4 + n // 4, Xi[n % 4]
                hn = h[i] + MD4_Generate.G(h[j], h[k], h[l]) + X[K] + 0x5A827999
                h[i] = MD4_Generate.lrot(hn & MD4_Generate.mask, S)

            # Round 3
            Xi = [3, 9, 11, 15]
            Ki = [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]
            for n in range(16):
                i, j, k, l = map(lambda x: x % 4, range(-n, -n + 4))
                K, S = Ki[n], Xi[n % 4]
                hn = h[i] + MD4_Generate.H(h[j], h[k], h[l]) + X[K] + 0x6ED9EBA1
                h[i] = MD4_Generate.lrot(hn & MD4_Generate.mask, S)

            self.h = [((v + n) & MD4_Generate.mask) for v, n in zip(self.h, h)]
            # print("self",self.h)

    @staticmethod
    def F(x, y, z):
        return (x & y) | (~x & z)

    @staticmethod
    def G(x, y, z):
        return (x & y) | (x & z) | (y & z)

    @staticmethod
    def H(x, y, z):
        return x ^ y ^ z

    @staticmethod
    def lrot(value, n):
        lbits, rbits = (value << n) & MD4_Generate.mask, value >> (MD4_Generate.width - n)
        return lbits | rbits


class MD4_Decrypt:
    """
    MD4_Decrypt is the class where MD4 hash is to be decrypt
    """

    def __init__(self, target_hash, dict_file='Rockyou.txt', verbose=0):
        """
        Default Initial Function
        :param target_hash: Encypt hash
        :param dict_file: wordlist file
        :param verbose: int, level of verbosity for output (default is 0).

        """
        self.target_hash = target_hash
        self.dict_file = dict_file
        self.verbose = verbose

    def decode(self):
        """
        :return: found hash and where it found that hash
        """

        console = Console()

        count = 0
        with open(self.dict_file, 'r', encoding='latin1') as f:
            for _ in f:
                count += 1
        print(f"\nTotal lines in Wordlist: {count}")

        line_count = 0
        try:
            with open(self.dict_file, 'r', encoding='latin1') as file:
                with console.status("[bold green]Working on tasks..."):
                    for line_num, line in enumerate(file, start=1):
                        line_count += 1
                        line = line.strip()  # Remove any trailing newline characters
                        hashed = MD4_Generate(line.encode()).hexdigest()
                        if self.verbose == 1:
                            print(line)
                        if hashed == self.target_hash:
                            return line, line_count
                        if line_num % (count // 10) == 0:  # Check if 10% of the file has been read
                            console.log(f"Wordlist reading {line_num * 100 // count}% done..")

            return 'None', line_count
        except KeyboardInterrupt:
            console.print("Process Stopped Keyboard Interruption......", style="bold red")


def ntlm_decode(user_hash, file, verbose=0):
    """
               Use to find NTLM hash

               :param user_hash:  str, containing hash.
               :param file:  str, path to the wordlist for hash cracking.
               :param verbose: int, level of verbosity for output (default is 0).
               :return: found hash and where it found that hash
               """
    # Enumerating file
    console = Console()
    cpu = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory().percent
    line_count = 0

    count = 0
    with open(file, 'r', encoding='latin1') as f:
        for _ in f:
            count += 1
    print(f"\nTotal lines in Wordlist: {count}")

    try:
        with open(file, "r", encoding='latin1') as file:
            with console.status(
                    f"[bold green]Working on tasks...\n\n\n[bold cyan]CPU Usage:[/bold cyan] {cpu}% [white] | [magenta]Memory Usage:[bold magenta] {memory}%"):
                for line_num, line in enumerate(file, start=1):
                    # print(line.strip())
                    line_count += 1
                    if verbose == 1:
                        print(nthash.hash(line.strip()), line.strip())
                    if nthash.verify(line.strip(), user_hash):
                        return line.strip(), line_count

                    if line_num % (count // 10) == 0:  # Check if 10% of the file has been read
                        console.log(f"Wordlist reading {line_num * 100 // count} % done..")

        return 'None', line_count
    except KeyboardInterrupt:
        console.print("Process Stopped Keyboard Interruption......", style="bold red")
        fl = float(line_count / count) * 100
        console.print(
            f"[magenta]Wordlist reading = [bold cyan]{fl:.2f} % [white] | Lines = [bold magenta] {line_count}[white]")


def sha1(inputs, file, verbose=0):
    """
               Use to find SHA1 hash

               :param inputs:  str, containing hash.
               :param file:  str, path to the wordlist for hash cracking.
               :param verbose: int, level of verbosity for output (default is 0).
               :return: found hash and where it found that hash
               """
    line_count = 0
    console = Console()

    count = 0
    with open(file, 'r', encoding='latin1') as f:
        for _ in f:
            count += 1
    print(f"\nTotal lines in Wordlist: {count}")

    try:
        # Open the file in read mode
        with open(file, 'r', buffering=1024 * 1024, encoding='latin1') as file:
            # Read each line in the file
            for line in file:
                line_count += 1  # Increment line count for each line read
                hashed = hashlib.sha1(line.strip().encode()).hexdigest()
                if verbose == 1:
                    print(hashed, line.strip())
                if inputs == hashed:
                    return line.strip(), line_count
        return 'None', line_count
    except KeyboardInterrupt:
        console.print("Process Stopped Keyboard Interruption......", style="bold red")


def md5(inputs, file, verbose=0):
    """
               Use to find MD5 hash

               :param inputs:  str, containing hash.
               :param file:  str, path to the wordlist for hash cracking.
               :param verbose: int, level of verbosity for output (default is 0).
               :return: found hash and where it found that hash
               """
    line_count = 0  # define variables to count number of lines
    console = Console()

    count = 0
    with open(file, 'r', encoding='latin1') as f:
        for _ in f:
            count += 1
    print(f"\nTotal lines in Wordlist: {count}")

    try:
        # Open the file in read mode
        with open(file, 'r', buffering=1024 * 1024, encoding='latin1') as file:
            with console.status("[bold green]Working on tasks..."):
                for line_num, line in enumerate(file, start=1):  # Read each line in the file
                    line_count += 1  # Increment line count for each line read
                    hashed = hashlib.md5(line.strip().encode()).hexdigest()
                    # print(hashed)
                    if verbose == 1:
                        print(hashed,line.strip())
                    if inputs == hashed:  # Check if the current line matches the input
                        return line.strip(), line_count
                    if line_num % (count // 10) == 0:  # Check if 10% of the file has been read
                        console.log(f"Wordlist reading {line_num * 100 // count}% done..")

        return 'None', line_count
    except KeyboardInterrupt:
        console.print("Process Stopped Keyboard Interruption......", style="bold red")


def md5_crypt(user_hash, wordlist, verbose=0):
    """
               Use to find MD5_Crypt hash

               :param user_hash:  str, containing hash.
               :param wordlist:  str, path to the wordlist for hash cracking.
               :param verbose: int, level of verbosity for output (default is 0).
               :return: found hash and where it found that hash
               """
    line_count = 0

    my_system = platform.system()

    if my_system == 'Linux':
        try:
            import crypt

            salt = user_hash.split('$')[2]
            for line_num, word in enumerate(wordlist, start=1):
                word = word.strip()
                hashed_word = crypt.crypt(word, f"$1${salt}$")
                if verbose == 1:
                    print(hashed_word)
                if hashed_word == user_hash:
                    return word, line_count
            return 'None', line_count
        except Exception as e:
            print(f"Error: {e}")
    else:
        print(f"OS Error: This hash function is only supported on Linux, not {my_system}.")


def sha256_crypt(user_hash, wordlist, verbose=0):
    """
               Use to find SHA256_Crypt hash

               :param user_hash:  str, containing hash.
               :param wordlist:  str, path to the wordlist for hash cracking.
               :param verbose: int, level of verbosity for output (default is 0).
               :return: found hash and where it found that hash
               """
    line_count = 0

    my_system = platform.system()

    if my_system == 'Linux':
        try:
            import crypt

            salt = user_hash.split('$')[2]
            for line_num, word in enumerate(wordlist, start=1):
                word = word.strip()
                hashed_word = crypt.crypt(word, f"$5${salt}$")
                if verbose == 1:
                    print(hashed_word)
                if hashed_word == user_hash:
                    return word, line_count
            return 'None', line_count
        except Exception as e:
            print(f"Error: {e}")
    else:
        print(f"OS Error: This hash function is only supported on Linux, not {my_system}.")


def sha256(inputs, file, verbose=0):
    """
               Use to find SHA256 hash

               :param inputs:  str, containing hash.
               :param file:  str, path to the wordlist for hash cracking.
               :param verbose: int, level of verbosity for output (default is 0).
               :return: found hash and where it found that hash
               """
    line_count = 0
    console = Console()

    count = 0
    with open(file, 'r', encoding='latin1') as f:
        for _ in f:
            count += 1
    print(f"\nTotal lines in Wordlist: {count}")

    try:
        # Open the file in read mode
        with open(file, 'r', buffering=1024 * 1024, encoding='latin1') as file:
            with console.status("[bold green]Working on tasks..."):
                # Read each line in the file
                for line_num, line in enumerate(file, start=1):
                    line_count += 1  # Increment line count for each line read
                    hashed = hashlib.sha256(line.strip().encode()).hexdigest()
                    # print(hashed)
                    if verbose == 1:
                        print(hashed, line.strip())
                    # Check if the current line matches the input
                    if inputs == hashed:  # Check if the current line matches the input
                        return line.strip(), line_count
                    if line_num % (count // 10) == 0:  # Check if 10% of the file has been read
                        console.log(f"Wordlist reading {line_num * 100 // count}% done..")
        return 'None', line_count
    except KeyboardInterrupt:
        console.print("Process Stopped Keyboard Interruption......", style="bold red")


def sha512(inputs, file, verbose=0):
    """
           Use to find SHA512 hash

           :param inputs:  str, containing hash.
           :param file:  str, path to the wordlist for hash cracking.
           :param verbose: int, level of verbosity for output (default is 0).
           :return: found hash and where it found that hash
           """


    line_count = 0
    console = Console()

    count = 0
    with open(file, 'r', encoding='latin1') as f:
        for _ in f:
            count += 1
    print(f"\nTotal lines in Wordlist: {count}")

    try:
        # Open the file in read mode
        with open(file, 'r', buffering=1024 * 1024, encoding='latin1') as file:
            # Read each line in the file
            for line_num, line in enumerate(file, start=1):
                line_count += 1  # Increment line count for each line read
                hashed = hashlib.sha512(line.strip().encode()).hexdigest()
                # print(hashed)
                if verbose == 1:
                    print(hashed, line.strip())
                # Check if the current line matches the input
                if inputs == hashed:  # Check if the current line matches the input
                    return line.strip(), line_count
                if line_num % (count // 10) == 0:  # Check if 10% of the file has been read
                    console.log(f"Wordlist reading {line_num * 100 // count}% done..")
        return 'None', line_count
    except KeyboardInterrupt:
        console.print("Process Stopped Keyboard Interruption......", style="bold red")


def sha512_crypt(user_hash, wordlist, verbose=0):
    """
        Use to find SHA512_Crypt hash

        :param user_hash:  str, containing hashes.
        :param wordlist:  str, path to the wordlist for hash cracking.
        :param verbose: int, level of verbosity for output (default is 0).
        :return: found hash and where it found that hash
        """
    line_count = 0

    my_system = platform.system()

    if my_system == 'Linux':
        try:
            import crypt

            salt = user_hash.split('$')[2]
            for line_num, word in enumerate(wordlist, start=1):
                word = word.strip()
                hashed_word = crypt.crypt(word, f"$6${salt}$")
                if verbose == 1:
                    print(hashed_word)
                if hashed_word == user_hash:
                    return word, line_count
            return 'None', line_count
        except Exception as e:
            print(f"Error: {e}")
    else:
        print(f"OS Error: This hash function is only supported on Linux, not {my_system}.")


def from_file(file, wordlist, verbosity=0):
    """
    Reads a file containing hashes, identifies their types, and attempts to find their plaintext values using a wordlist.

    Parameters:
    - file: str, path to the file containing hashes.
    - wordlist: str, path to the wordlist for hash cracking.
    - verbosity: int, level of verbosity for output (default is 0).
    """
    hashid = Hashid()
    hashes = []
    dictionery = {}

    try:
        with open(file, 'r', encoding='Latin1') as f:
            for line in f:
                cleaned_line = line.strip()
                if cleaned_line:  # Only process non-empty lines
                    hashes.append(cleaned_line)

        ntlm_hashes, md5_hashes, sha1_hashes, sha256_hashes, sha512_hashes, md5crypt_hashes, sha256crypt_hashes, sha512crypt_hashes, not_hash = hashid.identify_hashes(hashes)
        
        if not_hash:
            print(Fore.LIGHTCYAN_EX + "Unknown Hashes:" + Style.RESET_ALL)
            for hash_value in not_hash:
                print(hash_value)

        if md5_hashes:
            print("\nIdentified MD5 or NTLM Hashes:")
            for hash_value in md5_hashes:
                passwd, num = found(hash_value, 'MD5', wordlist, verbosity)
                if passwd == 'None' and num == -1:
                    passwd, num = found(hash_value, 'NTLM', wordlist, verbosity)
                out_dict[hash_value] = passwd
        if md5crypt_hashes:
            print("\nIdentified MD5 or MD5_Crypt Hashes:")
            for hash_value in md5crypt_hashes:
                passwd, num = found(hash_value, 'MD5_Crypt', wordlist, verbosity)
                out_dict[hash_value] = passwd
        if sha1_hashes:
            print("\nIdentified SHA1 Hashes:")
            for hash_value in sha1_hashes:
                passwd, num = found(hash_value, 'SHA1', wordlist, verbosity)
                out_dict[hash_value] = passwd
        if sha256_hashes:
            print("\nIdentified SHA256 Hashes:")
            for hash_value in sha256_hashes:
                passwd, num = found(hash_value, 'SHA256', wordlist, verbosity)
                out_dict[hash_value] = passwd
        if sha256crypt_hashes:
            print("\nIdentified SHA256-Crypt Hashes : ")
            for hash_value in sha1_hashes:
                passwd, num = found(hash_value, 'SHA256_Crypt', wordlist, verbosity)
                out_dict[hash_value] = passwd
        if sha512_hashes:
            print("\nIdentified SHA512 Hashes:")
            for hash_value in sha1_hashes:
                passwd, num = found(hash_value, 'SHA512', wordlist, verbosity)
                out_dict[hash_value] = passwd
        if sha512crypt_hashes:
            print("\nIdentified SHA512-Crypt Hashes:")
            for hash_value in sha1_hashes:
                passwd, num = found(hash_value, 'SHA512_Crypt', wordlist, verbosity)
                out_dict[hash_value] = passwd
        # print("\n\nPrinting\n")
        # for key, value in out_dict.items():
        #     print(f"{key} = {value}")

    except Exception as e:
        print(f"Error: {e}")


def found(user_hash, hash_ty, wordlist, verbose=0):
    """
    Take user hash and trigger appropriate hash type

    :param user_hash: str, containing hashes.
    :param hash_ty: Type of hash specify by user.
    :param wordlist: str, path to the wordlist for hash cracking.
    :param verbose: int, level of verbosity for output (default is 0).
    :return: password and line if success or Minus one(-1) if password not found
    """


    print(f"Searching Your {hash_ty} Hash : ", Fore.LIGHTRED_EX, user_hash, Style.RESET_ALL)
    try:
        match hash_ty:
            case 'MD5':  # MD5 hash
                passwd, line = md5(user_hash, wordlist, verbose)
                if passwd in [0, 'None']:
                    print(Fore.LIGHTRED_EX, "[-]", Style.RESET_ALL, "Password Not Found.....")
                    return 'None', -1
                else:
                    print(Fore.LIGHTGREEN_EX, "[+]", Style.RESET_ALL, "Hashed Found ", Fore.LIGHTGREEN_EX, "[",
                          passwd.strip(), "]", Style.RESET_ALL, "at Line = ", line)
                    return passwd, line

            case 'MD4':  # MD4 hash
                passwd, line = MD4_Decrypt(user_hash, wordlist, verbose).decode()
                if passwd in [0, 'None']:
                    print(Fore.LIGHTRED_EX, "[-]", Style.RESET_ALL, "Password Not Found.....")
                    return 'None', -1
                else:
                    print(Fore.LIGHTGREEN_EX, "[+]", Style.RESET_ALL, "Hashed Found ", Fore.LIGHTGREEN_EX, "[",
                          passwd.strip(), "]", Style.RESET_ALL, "at Line = ", line)
                    return passwd, line

            case 'SHA1':  # SHA1 hash
                passwd, line = sha1(user_hash, wordlist, verbose)
                if passwd in [0, 'None']:
                    print(Fore.LIGHTRED_EX, "[-]", Style.RESET_ALL, "Password Not Found.....")
                    return 'None', -1
                else:
                    print(Fore.LIGHTGREEN_EX, "[+]", Style.RESET_ALL, "Hashed Found ", Fore.LIGHTGREEN_EX, "[",
                          passwd.strip(), "]", Style.RESET_ALL, "at Line = ", line)
                    return passwd, line

            case 'SHA256':  # SHA256 hash
                passwd, line = sha256(user_hash, wordlist, verbose)
                if passwd in [0, 'None']:
                    print(Fore.LIGHTRED_EX, "[-]", Style.RESET_ALL, "Password Not Found.....")
                    return 'None', -1
                else:
                    print(Fore.LIGHTGREEN_EX, "[+]", Style.RESET_ALL, "Hashed Found ", Fore.LIGHTGREEN_EX, "[",
                          passwd.strip(), "]", Style.RESET_ALL, "at Line = ", line)
                    return passwd, line

            case 'SHA512':  # SHA512 hash
                passwd, line = sha512(user_hash, wordlist, verbose)
                if passwd in [0, 'None']:
                    print(Fore.LIGHTRED_EX, "[-]", Style.RESET_ALL, "Password Not Found.....")
                    return 'None', -1
                else:
                    print(Fore.LIGHTGREEN_EX, "[+]", Style.RESET_ALL, "Hashed Found ", Fore.LIGHTGREEN_EX, "[",
                          passwd.strip(), "]", Style.RESET_ALL, "at Line = ", line)
                    return passwd, line

            case 'NTLM':  # NTLM hash
                passwd, line = ntlm_decode(user_hash, wordlist, verbose)
                if passwd in [0, 'None']:
                    print(Fore.LIGHTRED_EX, "[-]", Style.RESET_ALL, "Password Not Found.....")
                    return 'None', -1
                else:
                    print(Fore.LIGHTGREEN_EX, "[+]", Style.RESET_ALL, "Hashed Found ", Fore.LIGHTGREEN_EX, "[",
                          passwd.strip(), "]", Style.RESET_ALL, "at Line = ", line)
                    return passwd, line

            case 'MD5_Crypt':  # MD5_crypt hash
                passwd, line = md5_crypt(user_hash, wordlist, verbose).decode()
                if passwd in [0, 'None']:
                    print(Fore.LIGHTRED_EX, "[-]", Style.RESET_ALL, "Password Not Found.....")
                    return 'None', -1
                else:
                    print(Fore.LIGHTGREEN_EX, "[+]", Style.RESET_ALL, "Hashed Found ", Fore.LIGHTGREEN_EX, "[",
                          passwd.strip(), "]", Style.RESET_ALL, "at Line = ", line)
                return passsd, line

            case 'SHA256_Crypt':  # MD5_crypt hash
                passwd, line = sha256_crypt(user_hash, wordlist, verbose).decode()
                if passwd in [0, 'None']:
                    print(Fore.LIGHTRED_EX, "[-]", Style.RESET_ALL, "Password Not Found.....")
                    return 'None', -1
                else:
                    print(Fore.LIGHTGREEN_EX, "[+]", Style.RESET_ALL, "Hashed Found ", Fore.LIGHTGREEN_EX, "[",
                          passwd.strip(), "]", Style.RESET_ALL, "at Line = ", line)
                return passwd, line

            case 'SHA512_Crypt':  # MD5_crypt hash
                passwd, line = sha512_crypt(user_hash, wordlist, verbose).decode()
                if passwd in [0, 'None']:
                    print(Fore.LIGHTRED_EX, "[-]", Style.RESET_ALL, "Password Not Found.....")
                    return 'None', -1
                else:
                    print(Fore.LIGHTGREEN_EX, "[+]", Style.RESET_ALL, "Hashed Found ", Fore.LIGHTGREEN_EX, "[",
                          passwd.strip(), "]", Style.RESET_ALL, "at Line = ", line)
                return passwd, line





    except FileNotFoundError:
        print(Fore.LIGHTRED_EX, "\nError: The wordlist file was not found.", Style.RESET_ALL)
    except Exception as e:
        print(Fore.LIGHTRED_EX, f"\nAn unexpected error occurred: {e}", Style.RESET_ALL)


def out_file(output_file,wordlist, line=0):
    """
    To write Found hashes to a file [default out.txt]
    :param output_file:
    :param wordlist:
    :param line:
    :return: void
    """
    # Check if out_dict is defined and is a dictionary
    if 'out_dict' not in globals() or not isinstance(out_dict, dict):
        print("No hash loaded, No output file created...")
        return

    # Check if the dictionary is empty
    if not out_dict:
        print("The dictionary is empty, No output file created...")
        return

    try:
        with open(output_file, 'w') as f:
            f.write(f"Your wordlist = '{wordlist}'\n\n")
            for key, value in out_dict.items():  # Correctly call items()
                data = f"{key} = {value} \n"
                f.write(data)
        print(f"Output successfully written to {output_file}")
    except IOError as e:
        print(f"An error occurred while writing to the file: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")


def helper():
    """
    Helper When user don't know what to do.
    :return:Void
    """
    print("\nHash Decoder (v1.0) Starting help mode.....\n")
    time.sleep(2)
    print("Usage:")
    print("======")
    print("-> python hashDecoder.py [hash-type] [your-hash] [wordlist]")
    print("\nHash Type:-\n=========")
    print("-m4,   --md4      To Crack Message Digest 4 Hash, use -m4 or --md4")
    print("-m5,   --md5      To Crack Message Digest 5 Hash, use -m5 or --md5")
    print("-s1,   --sha1     To Decode SHA1 Hash, use -s1 or --sha1")
    print("-s256, --sha256   To Decode SHA256 Hash, use -s256 or --sha256")
    print("-s512, --sha512   To Decode SHA256 Hash, use -s512 or --sha512")
    print("--ntlm            To Crack NTLM Hash use --ntlm\n")
    print()
    print("-md5crypt, --md5_crypt           To crack MD5 crypt hash id:$1 [use in linux os] ")
    print("-sha256crypt, --sha256_crypt     To crack MD5 crypt hash id:$5 [use in linux os] ")
    print("-sha512crypt, --sha512_crypt     To crack MD5 crypt hash id:$6 [use in linux os] ")
    print()
    print("Wordlist:\n========")
    print("-w, --wordlist       Use -w or --wordlist to specify wordlist by default hash decoder use Rockyou.txt")
    print()
    print("-q, --quite          To Quite Banner....")
    print("-v, --verbose        To enable Verbose [Note: Reduce Speed]....")
    print("-f, --file           A text file in which List of hashes stored...[Note: Please give only one file at a time]....")
    print("-o,  --output        To Write a Found hashes to a file.... [default out.txt]")
    print("-ar, --append-result To append the reult to an existing file.... [Make sure the file is exist]")
    print("Example:\n========")
    print("python hashDecoder.py --md5 527bd5b5d689e2c32ae974c6229ff785 -w /usr/share/wordlists/rockyou.txt")
    print("python hashDecoder.py --md5 527bd5b5d689e2c32ae974c6229ff785 ")
    print("python3 hashDecoder.py --md5 527bd5b5d689e2c32ae974c6229ff785 -w /usr/share/wordlists/rockyou.txt -v")
    print()


def banners():
    """
    Hash Decoder Banner
    :return:
    """
    my_system = platform.system()
    if my_system.lower() == 'windows':
        os.system('cls')
    else:
        os.system('clear')
    num = random.randint(1, 5)

    if num == 1:
        print(Fore.LIGHTCYAN_EX, """
        ___ ___               .__      ________                          .___            
     /   |   \_____    _____|  |__   \______ \   ____   ____  ____   __| _/___________ 
    /    ~    \__  \  /  ___/  |  \   |    |  \_/ __ \_/ ___\/  _ \ / __ |/ __ \_  __ \\
    \    Y    // __ \_\___ \|   Y  \  |    `   \  ___/\  \__(  <_> ) /_/ \  ___/|  | \/
     \___|_  /(____  /____  >___|  / /_______  /\___  >\___  >____/\____ |\___  >__|   
           \/      \/     \/     \/          \/     \/     \/           \/    \/   
        """)

        txt = " by Kaif Shah "
        print(Style.RESET_ALL, txt.center(90, "="))

    elif num == 2:
        print(Fore.LIGHTGREEN_EX, """
         /$$   /$$                     /$$             /$$$$$$$                                      /$$                    
        | $$  | $$                    | $$            | $$__  $$                                    | $$                    
        | $$  | $$  /$$$$$$   /$$$$$$$| $$$$$$$       | $$  \ $$  /$$$$$$   /$$$$$$$  /$$$$$$   /$$$$$$$  /$$$$$$   /$$$$$$ 
        | $$$$$$$$ |____  $$ /$$_____/| $$__  $$      | $$  | $$ /$$__  $$ /$$_____/ /$$__  $$ /$$__  $$ /$$__  $$ /$$__  $$
        | $$__  $$  /$$$$$$$|  $$$$$$ | $$  \ $$      | $$  | $$| $$$$$$$$| $$      | $$  \ $$| $$  | $$| $$$$$$$$| $$  \__/
        | $$  | $$ /$$__  $$ \____  $$| $$  | $$      | $$  | $$| $$_____/| $$      | $$  | $$| $$  | $$| $$_____/| $$      
        | $$  | $$|  $$$$$$$ /$$$$$$$/| $$  | $$      | $$$$$$$/|  $$$$$$$|  $$$$$$$|  $$$$$$/|  $$$$$$$|  $$$$$$$| $$      
        |__/  |__/ \_______/|_______/ |__/  |__/      |_______/  \_______/ \_______/ \______/  \_______/ \_______/|__/  
        """)
        txt = " by Kaif Shah "
        print(Style.RESET_ALL, txt.center(90, "="))
    elif num == 3:
        print(Fore.LIGHTRED_EX, """
          _    _           _       _____                     _           
         | |  | |         | |     |  __ \                   | |          
         | |__| | __ _ ___| |__   | |  | | ___  ___ ___   __| | ___ _ __ 
         |  __  |/ _` / __| '_ \  | |  | |/ _ \/ __/ _ \ / _` |/ _ \ '__|
         | |  | | (_| \__ \ | | | | |__| |  __/ (_| (_) | (_| |  __/ |   
         |_|  |_|\__,_|___/_| |_| |_____/ \___|\___\___/ \__,_|\___|_|  
        """)
        txt = " by Kaif Shah "
        print(Style.RESET_ALL, txt.center(90, "="))
    elif num == 4:
        print(Fore.LIGHTMAGENTA_EX, """
    ██╗  ██╗ █████╗ ███████╗██╗  ██╗    ██████╗ ███████╗ ██████╗ ██████╗ ██████╗ ███████╗██████╗ 
    ██║  ██║██╔══██╗██╔════╝██║  ██║    ██╔══██╗██╔════╝██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔══██╗
    ███████║███████║███████╗███████║    ██║  ██║█████╗  ██║     ██║   ██║██║  ██║█████╗  ██████╔╝
    ██╔══██║██╔══██║╚════██║██╔══██║    ██║  ██║██╔══╝  ██║     ██║   ██║██║  ██║██╔══╝  ██╔══██╗
    ██║  ██║██║  ██║███████║██║  ██║    ██████╔╝███████╗╚██████╗╚██████╔╝██████╔╝███████╗██║  ██║
    ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚═════╝ ╚══════╝ ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝                                                                                                                                                                                                                                                                                                                                                           
        """)
        txt = " by Kaif Shah "
        print(Style.RESET_ALL, txt.center(90, "="))

    elif num == 5:
        print(Fore.GREEN, """
         __    __       ___           _______. __    __      _______   _______   ______   ______    _______   _______ .______      
        |  |  |  |     /   \         /       ||  |  |  |    |       \ |   ____| /      | /  __  \  |       \ |   ____||   _  \     
        |  |__|  |    /  ^  \       |   (----`|  |__|  |    |  .--.  ||  |__   |  ,----'|  |  |  | |  .--.  ||  |__   |  |_)  |    
        |   __   |   /  /_\  \       \   \    |   __   |    |  |  |  ||   __|  |  |     |  |  |  | |  |  |  ||   __|  |      /     
        |  |  |  |  /  _____  \  .----)   |   |  |  |  |    |  '--'  ||  |____ |  `----.|  `--'  | |  '--'  ||  |____ |  |\  \----.
        |__|  |__| /__/     \__\ |_______/    |__|  |__|    |_______/ |_______| \______| \______/  |_______/ |_______|| _| `._____|
        """)
        txt = " by Kaif Shah "
        print(Style.RESET_ALL, txt.center(90, "="))
    # elif num == 6:
    #     print(Fore.LIGHTGREEN_EX, """
    #     ####    ####        ###             #####       ####    ####
    #     ####    ####       #####        #####   ####    ####    ####
    #     ####    ####     ###    ###     ####            ####    ####
    #     ############    ####    ####    #############   ############
    #     ############    ############            #####   ############
    #     ####    ####    ####    ####   ####     #####   ####    ####
    #     ####    ####    ####    ####    ############    ####    ####
    #     ####    ####    ####    ####       ######       ####    ####
    #         """, Fore.LIGHTRED_EX,
    #
    #           """
    #     #########       ###########     ##########        #########       #########       ###########    #########
    #     ###     ####    ###########    ############     ##############    ###     ####    ###########   ###      ####
    #     ###      ####   ###           ####      ####  #####       #####   ###      ####   ###           ###       ####
    #     ###       ####  ########      ####            #####       #####   ###       ####  ########      ###       ####
    #     ###       ####  ########      ####            #####       #####   ###       ####  ########      #############
    #     ###      ####   ###           ####      ####  #####       #####   ###      ####   ###           ####   #####
    #     ###     ####    ###########    ############     ##############    ###     ####    ###########   ###     ####
    #     ##########      ###########      #########        #########       ##########      ###########   ###       ###
    #     """)
    #     txt = " by Kaif Shah "
    #     print(Style.RESET_ALL, txt.center(90, "="))


# main function
def main():
    """
    Main Function
    :return: none
    """

    start_time = time.time()
    default_file = 'Rockyou.txt'

    if '-q' in sys.argv or '--quite' in sys.argv:
        my_system = platform.system()
        if my_system.lower() == 'windows':
            os.system('cls')
        else:
            os.system('clear')
    else:
        banners()



    try:
        if '--help' in sys.argv or '-h' in sys.argv:
            print(Fore.LIGHTRED_EX, "\nError :\nYou must specify a hash type and a hash value.", Style.RESET_ALL)
            helper()
            return

        hash_type = sys.argv[1]
        user_hash = sys.argv[2]
        wordlist = default_file  # Default wordlist
        verbose = 0
        out_filename = 'out.txt'



        if '-v' in sys.argv or '--verbose' in sys.argv:
            verbose = 1
        print(sys.argv)


        # Now Running hash Decode Algorithm
        if hash_type.lower() in ['--md5', '-m5']:  # MD5
            passwd, num = found(user_hash, 'MD5', wordlist, verbose)
            if passwd != 'None' or num != -1:
                out_dict[user_hash] = passwd

        elif hash_type.lower() in ['--md4', '-m4']:  # MD4
            passwd, num = found(user_hash, 'MD4', wordlist, verbose)
            if passwd != 'None' or num != -1:
                out_dict[user_hash] = passwd
        elif hash_type.lower() in ['--sha1', '-s1']:  # SHA1
            passwd, num = found(user_hash, 'SHA1', wordlist, verbose)
            if passwd != 'None' or num != -1:
                out_dict[user_hash] = passwd
        elif hash_type.lower() in ['--sha256', '-s256']:  # SHA256
            passwd, num = found(user_hash, 'SHA256', wordlist, verbose)
            if passwd != 'None' or num != -1:
                out_dict[user_hash] = passwd
        elif hash_type.lower() in ['--sha512', '-s512']:  # SHA512
            passwd, num = found(user_hash, 'SHA512', wordlist, verbose)
            if passwd != 'None' or num != -1:
                out_dict[user_hash] = passwd
        elif hash_type.lower() == '--ntlm':  # NTLM
            passwd, num = found(user_hash, 'NTLM', wordlist, verbose)
            if passwd != 'None' or num != -1:
                out_dict[user_hash] = passwd
        elif hash_type.lower() in ['-md5crypt', '--md5_crypt']:  # MD5_Crypt
            passwd, num = found(user_hash, 'MD5_Crypt', wordlist, verbose)
            if passwd != 'None' or num != -1:
                out_dict[user_hash] = passwd
        elif hash_type.lower() in ['-smd5', '--salt:md5']:  # Salt:MD5
            passwd, num = found(user_hash, 'Salt:MD5', wordlist, verbose)
            if passwd != 'None' or num != -1:
                out_dict[user_hash] = passwd
        elif '-f' in sys.argv :        # for input File
            index = sys.argv.index('-f')
            from_file(sys.argv[index + 1],wordlist,verbose)
        elif '--file' in sys.argv :  # input file
            index = sys.argv.index('--file')
            from_file(sys.argv[index + 1],wordlist,verbose)
        elif '--wordlist' in sys.argv:    # user wordlist for dir brute force
            index = sys.argv.index('--wordlist')
            wordlist = sys.argv[index]
        elif '-w' in sys.argv:          # user wordlist for dir brute force
            index = sys.argv.index('-w')
            wordlist = sys.argv[index]
            print()

        else:
            print(Fore.LIGHTRED_EX, "\nError: Invalid hash type specified.", Style.RESET_ALL)
            helper()


        if '-o' in sys.argv:
            index = sys.argv.index('-o')
            out_filename = sys.argv[index + 1]
            out_file(out_filename, wordlist)
        elif '--output' in sys.argv:
            index = sys.argv.index('--output')
            out_filename = sys.argv[index + 1]
            print(out_filename)
            out_file(out_filename, wordlist)
        else:
            pass


    except IndexError:
        print(Fore.LIGHTRED_EX, "\nError: Missing command-line arguments.", Style.RESET_ALL)
        helper()
    except Exception as e:
        print(Fore.LIGHTRED_EX, f"\nAn unexpected error occurred: {e}", Style.RESET_ALL)
    finally:
        print(f"Execution Time of main = {time.time() - start_time} seconds")
        print("\n")


if __name__ == "__main__":
    try:
        main()
    except:
        pass
